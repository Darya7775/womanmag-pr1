import {initYearChecker} from './init-year-correction';

window.addEventListener('DOMContentLoaded', () => {
  window.addEventListener('load', () => {
    initYearChecker();
  });
});
